favorite_poem = """

CLOCK by Neil Gaiman
wastes of time
Must go
Since sweets and When I do
Count the clock that tells the time
And see the brave day sunk
In hideous night

When I behold the violet, past prime
Sable curls all silver dore and white
When lofty trees I see
Barren of leaves
Which erst from heat
That cannopy the herd
And summers green
All girded up in sheaves
Born on the bier
With white and gristly beard
Then of thy beauty
Do I question make
That thou amoung the beautiеs do themselves forsakе and die
As fast as they see others grow

MOBIUS STRIP by Neil Gaiman
My grandfather took a strip of paper
"Do you want to see something magic?"
He asked
I nodded
"Look," he said
"One side, two sides
But if I give it twist before I glue it, it only has one side"

I knew that was imposible
I took a pen and traced along it and wound up
Somehow
Back where I began
"Only one side!" he said
"What do you think will happen if I cut it? Into two? Along the middle of the strip?"
"Two loops?" I said
He showed me how to cut, and I cut along the strip
It opened into one enormous loop
Then he made anothеr strip, this time he twisted it twicе before he glued it
I cut
Now there was two loops, alright
But they were linked, connected, one through the other one
"Magic." I said
"That's right," he said, "magic!
It's all in the twist. It's the twist that brings you back where you started."

And I'm walking along along the strip now
Thinknig that there are two sides to every question, two sides to every coin
That the world is what I think it is
And that memory plays you straight
And nothing is tricky
And I'm walking on

BLOODY SUNRISE by Neil Gaiman
Verse 1:
Every night when I crawl out of my grave
Looking for someone to meet
Some way that we'll misbehave
Every night when I go out on the prowl
And then I fly through the night
With the bats and the owls
Every time I meet somebody
I think you might be the one
I've been on my own for too long
Bloody sunrise comes again
When I pull them closer to me

Chorus:
Leaves me hungry and alone
Every time
Bloody sunrise comes again
And I'm nowhere to be found
Every time
And you're a memory and gone
Something else that I can blame on
Bloody sunrise

Verse 2:
Every night I put on my smartest threads
And I go into the town
And I don't even look dead
Every night I smile and I say hi
And no one ever smiles back
And if I could I'd just die
But when I'm lucky, I do get lucky
And I think you might be the one
Even though the time is flying
When it gets to the time of dying

THE WRECKERS by Neil Gaiman
Huge moments of surprise, that leave you wrecked.

The wreckers, on the old, black, Cornish, rocks (when there was no moonlight, and hard storms pushed the waves and winds to treachery) would light their lamps to lure the ships ashore. And ships, who thought that they were safe, and lights were there to guide them home, would run aground, all hands lost and stolen by the cold sea.

To share the good times is to share the bad timеs. To share the joy in the finе-wine-times, is to drink the wine down to the bottom of the glass, where things are bitter. I will not ask for any glass to pass from me. There are no accidents (or possibly there are. But things happen because of their nature. And there is no arguing with Nature. For she is wise, and innocent, and cruel. And rage and hurt and pain and blood are hers).

So we build rituals of mourning and acceptance, to walk us through the nights of tears and pain. But Nature lost a daughter, who remains six seeds of pomegranate dead today.

Three things I send you. First I send these words, that you may use them as a pool of ink, to see yourself reflected, or see another in. To see far-away things, so you do not forget to dream. And then I send you pain, a small pain to whisper to your pain and keep it company. And last, I send a smile, that it might serve you well. And you may hold it in a time when smiles are scarce.
Remembering the moonlight on the water.

SONG OF THE SONG by Neil Gaiman
There's a song, that they sing at the edge of the world
About leaders and armies with banners unfurled
And the blood, of the brave on the glittering sand
While the mountaintops ring to the crash of the band
And they sing it a lot, it might even be true
But it's not
Listen, you

There's a boy, loves a girl, she has skin fair as milk
She has breasts like ripe apples and lips soft as silk
So he sings of such stuff, how he'll love her for [a?]
Though he's ragged and rough and he sleeps in the hay
For love makes no mistakes, but he's perfect and clean
She is gone, when he wakes, and I mean

You can never trust that song whatever you've heard (Whatever you heard)
Songs are just sweet illusions made of words (Words and lies)
Everybody loves a song
So reach for the sky (So reach for the sky)
Songs will just fool and trap you, made of lies
(Ra-ta-ta-ta-ta-ta-ta, ra-ta-ta-ta-ta-ta-ta)
(Ra-ta-ta-ta-ta-ta-ta)

On each side of the border
Wherever you stand in these days of disorder
You must understand
That some songs are convincing
Persuasive and smart
So in moments they're mincing away with your heart
Like songs do
They inspire, but beware because song, like desire, can go wrong

CREDO by Neil Gaiman
I believe that it is difficult to kill an idea, because ideas are invisible and contagious, and they move fast

I believe that you can set your own ideas against ideas you dislike. That you should be free to argue, explain, clarify, debate, offend, insult, rage, mock, sing, dramatise and deny

I do not believe that burning, murdering, exploding people, smashing their heads with rocks (to let the bad ideas out), drowning them or even defeating them will work to contain ideas you do not like. Ideas spring up where you do not expect them, like weeds, and are as difficult to control

I believe that repressing ideas spreads ideas

I believe that people and books and newspapers are containers for ideas, but that burning the people who hold the ideas will be as unsuccessful as firebombing the newspaper archives. It is already too late. It is always too late. The ideas are out, hiding behind people's eyes, waiting in their thoughts. They can be whispered. They can be written on walls in the dead of night. They can be drawn

I believe that ideas do not have to be correct to exist

I believe you have every right to be perfectly certain that images of god or prophet or man are sacred and undefilable, just as I have the right to be certain of the sacredness of speech, and of the sanctity of the right to mock, comment, to argue and to utter

I believe I have the right to think and say the wrong things. I believe your remedy for that should be to argue with me or to ignore me, and that I should have the same remedy for the wrong things that I believe you think

I believe that you have the absolute right to think things that I find offensive, stupid, preposterous or dangerous, and that you have the right to speak, write, or distribute these things, and that I do not have the right to kill you, maim you, hurt you, or take away your liberty or property because I find your ideas threatening or insulting or downright disgusting. You probably think some of my ideas are pretty vile, too

I believe that in the battle between guns and ideas, ideas will, eventually, win

Because the ideas are invisible, and they linger, and, sometimes, they can even be true

Eppur si muove: and yet it moves...

POEM FIRST READ ON JANUARY 26TH 2011 AT THE SYDNEY OPERA HOUSE by Neil Gaiman
We killed them all when we came here
The people came and burned their land
The forests where they used to feed
We burned the trees that gave them shade
And burned to bush, to scrub, to heath
We made it easier to hunt
We changed the land, and they were gone

Today our beasts and dreams are small
As species fall to time and us
But back before the black folk came
Before the white folk's fleet arrived
Before we built our cities here
Before the casual genocide
This was the land where nightmares loped
And hopped and ran and crawled and slid
And then we did the things we did
And thus we died the things we died

We have not seen Diprotodon
A wombat bigger than a room
Or run from Dromornithidae
Gigantic demon ducks of doom
All motor legs and ripping beaks
A flock of geese from hell's dark maw
We've lost carnivorous kangaroo
A bouncy furrier T-Rex
And Thylacoleo Carnifex
The rat-king-devil-lion-thing
The dropbear fantasy made flesh
Quinkana, the land crocodile
Five metres long and fast as fright
Wonambi, the enormous snake
Who waited by the water-holes
And took the ones who came to drink
Who were not watchful, clever, bright
Our Thylacines were tiger-wolves
Until we drove them off the map
Then Megalania: seven meters
Of venomous enormous lizard
And more, and more
The ones whose bones we've never seen
The megafauna haunt our dreams
This was their land before mankind
Just fifty thousand years ago

THE PROBLEM WITH SAINTS by Neil Gaiman
[Verse 1]
I wish that Joan of Arc wouldn't hang around the park
Pronouncing that she won't get burned again
Her armour's very shiny and her message is divine
But I wish she'd take a day off now and then
She says it clears your head when you come back from the dead
With your sword as sharp as anything that cuts
And to prove it, she bisected three young tourists from Utrecht
Which rapidly displayed a lot of guts

[Chorus]
She says we need to raise a brand new army
And the flag of France so proudly she unfurled
And the people that she hated will be neatly bifurcated
And thе British will no longer rule the world

[Verse 2]
Shе says it was a mistake to let them burn her at the stake
And she learned a lesson back there in the flames
So she's going to kill the queen and then she'll rescue Old Orleans
And it's really hard to hang around with saints
I think I ought to tell her that the English left in failure
And they don't go back to France except on hols
But I saw her vivisect a man who wanted to correct her
And the playground soon resembled Grand Guignol

IN TRANSIT by Neil Gaiman
[Verse 1]
I wish that Joan of Arc wouldn't hang around the park
Pronouncing that she won't get burned again
Her armour's very shiny and her message is divine
But I wish she'd take a day off now and then
She says it clears your head when you come back from the dead
With your sword as sharp as anything that cuts
And to prove it, she bisected three young tourists from Utrecht
Which rapidly displayed a lot of guts

[Chorus]
She says we need to raise a brand new army
And the flag of France so proudly she unfurled
And the people that she hated will be neatly bifurcated
And thе British will no longer rule the world

[Verse 2]
Shе says it was a mistake to let them burn her at the stake
And she learned a lesson back there in the flames
So she's going to kill the queen and then she'll rescue Old Orleans
And it's really hard to hang around with saints
I think I ought to tell her that the English left in failure
And they don't go back to France except on hols
But I saw her vivisect a man who wanted to correct her
And the playground soon resembled Grand Guignol

SIGN OF LIFE by Neil Gaiman
And in the end, there's just a dented pillow
Where a head lay
And in the end, you reach an arm out
But there's no one closer
And in the end, there's just an empty pillow
Not a person
And then it's over
So there's nothing, just a vacant pillow

All the dreams
All the songs
All the words
All the books
All the keys
All the jokes
All the jokes
Goodnight, face
Goodbye, clock
Farewell, words
Farewell, words

You can't just lie there!
There are things to do, you silly person
And people still living inside your head
Your cold head
"You know how this goes," you used to say to me
"Now look," you'd say, "Think about it," you'd tell me
"It's so obvious. You know how this one goes"
You might also like
And all the songs you would have sung that never will be heard now
And all the ways you walked that never will be walked in future
And all the things we did we'll never do again together
And all the memories of pain or joy that only we shared
I am custodian, but all our words are writ on water
We are custodians, but all our words are writ on water

You aren't waiting for me
It doesn't work like that
"Make your own music," you said
"It's time to go on alone"
You can't be dead. You can't!
Get up. You have to work now
Now that they've come to take you away
Wash you, and wind you, and take you away

(Ooh-ooh-ooh-ooh-ooh)
(Ooh-ooh-ooh-ooh)
You know how this one goes! (Ooh-ooh-ooh-ooh-ooh)
(Ooh-ooh-ooh-ooh-ooh)
(Ooh-ooh-ooh-ooh-ooh)
(Ooh-ooh-ooh)

Can you remember what a pillow was?
Do you remember how it felt to feel?

Goodnight, face
Goodbye, breath
Farewell, words
No more time
No more clock

Let it dissolve
Like a dent on a pillow
Or breath on a window
That fades
And then we turn, and there's nobody left to turn, or nothing
There's no body. Just signs of a life that was spent.

TIME by Pink Floyd 
Verse 1
Ticking away the moments that make up a dull day
Fritter and waste the hours in an offhand way
Kicking around on a piece of ground in your hometown
Waiting for someone or something to show you the way
Tired of lying in the sunshine
Staying home to watch the rain
And you are young and life is long
And there is time to kill today
And then one day you find
Ten years have got behind you
No one told you when to run
You missed the starting gun

Verse 2
And you run, and you run to catch up with the sun
But it's sinking
Racing around to come up behind you again
The sun is the same in a relative way
But you're older
Shorter of breath, and one day closer to death
Every year is getting shorter
Never seem to find the time
Plans that either come to naught
Or half a page of scribbled lines
Hanging on in quiet desperation is the English way
The time is gone, the song is over
Thought I'd something more to say

"""

least_favorite_poem = """
The Day is Done by Henry Wadsworth Longfellow

The day is done, and the darkness
Falls from the wings of Night,
As a feather is wafted downward
From an eagle in his flight.

I see the lights of the village
Gleam through the rain and the mist,
And a feeling of sadness comes o'er me
That my soul cannot resist.

A feeling of sadness and longing,
That is not akin to pain,
And resembles sorrow only
As the mist resembles the rain.

The Road Not Taken by Robert Frost

Two roads diverged in a yellow wood,
And sorry I could not travel both
And be one traveler, long I stood
And looked down one as far as I could
To where it bent in the undergrowth;

Then took the other, as just as fair,
And having perhaps the better claim,
Because it was grassy and wanted wear;
Though as for that the passing there
Had worn them really about the same,

And both that morning equally lay
In leaves no step had trodden black.
Oh, I kept the first for another day!
Yet knowing how way leads on to way,
I doubted if I should ever come back.

I shall be telling this with a sigh
Somewhere ages and ages hence:
Two roads diverged in a wood, and I—
I took the one less traveled by,
And that has made all the difference.

"""

print_favorite = True

if print_favorite:
    print("Favorite Poem:")
    print(favorite_poem)
else:
    print("Least Favorite Poem:")
    print(least_favorite_poem)




