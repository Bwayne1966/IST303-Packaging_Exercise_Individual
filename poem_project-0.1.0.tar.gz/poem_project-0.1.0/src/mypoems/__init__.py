
from .poems import favorite_poem, least_favorite_poem
