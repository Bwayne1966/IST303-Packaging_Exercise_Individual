Licensed under the MIT License (2023)

PACKAGING EXERCISE - INDIVIDUAL
Write a Python program called poems.py that stores your favorite and least favorite poems in variables
named favorite poem and least favorite poem respectively. Your poems can be in a language
of your choice. Using the instructions from Okken Appendix 4, create a source distribution of
the program which includes a version number, README file, change log, and a license. A list of
licenses can be found here: https://choosealicense.com/licenses/.
The following directory structure will be helpful:
Figure 1: Directory Structure for Poems Project.
